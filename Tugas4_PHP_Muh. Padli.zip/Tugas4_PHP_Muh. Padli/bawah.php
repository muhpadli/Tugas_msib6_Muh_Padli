<div class="footer" style="text-align: center; background-color: darkcyan; color:white; margin-top: 25px;">Copyright &copy; 2024 by Muh. Padli</div>

</body>

</html>