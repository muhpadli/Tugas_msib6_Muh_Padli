<h2 align="center">Galery</h2>
<div class="galery-foto">
    <img class="gal" src="image/galery01.jpg" alt="">
    <img class="gal" src="image/galery02.jpg" alt="">
    <img class="gal" src="image/galery03.jpg" alt="">
    <img class="gal" src="image/galery04.jpg" alt="">
    <img class="gal" src="image/galery05.jpg" alt="">
    <img class="gal" src="image/galery06.jpg" alt="">
</div>