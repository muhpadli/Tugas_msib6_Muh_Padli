<h2 align="center">Gesbuk</h2>
<table align="center" width="80%">
    <tbody>
        <tr>
            <td><label for="">Nama Lengkap</label></td>
            <td>:</td>
            <td style="width: 850px;"><input type="text" placeholder="Masukkan Nama Anda!"></td>
        </tr>
        <tr>
            <td><label for="">e-mail</label></td>
            <td>:</td>
            <td style="width: 850px;"><input type="text" placeholder="example : padl@gmail.com"></td>
        </tr>
        <tr>
            <td><label for="">website</label></td>
            <td>:</td>
            <td style="width: 850px;"><input type="text" placeholder="example : https://myportofolio.com"></td>
        </tr>
        <tr>
            <td><label for="">Saran</label></td>
            <td>:</td>
            <td style="width: 850px;">
                <textarea name="" placeholder="masukkan saran teraik anda!" id="" cols="51" rows="10"></textarea>
            </td>
        </tr>
        <tr>
        <td></td>
            <td></td>
            <td><button type="submit">Kirim</button></td>
        </tr>
    </tbody>
</table>
