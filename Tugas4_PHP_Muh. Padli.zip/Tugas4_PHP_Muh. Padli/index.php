<?php
include_once 'atas.php';
include_once 'isi.php';
include_once 'bawah.php';
?>