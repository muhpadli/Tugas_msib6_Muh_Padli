<fieldset style="margin: 20px; padding: 30px; ">
    <legend>Welcome to my Homepage</legend>
    <figure style="float: left;">
        <img src="./image/myFoto.jpeg" width="150px" height="200px"
            style=" border-radius: 70px; margin-right: 30px;" alt="">
            <figcaption>Founder CV. MP-Electronic
            </figcaption>
    </figure>
    <p>Halo guyss, perkenalkan nama lengkap saya Muh. padli dan nama panggilan saya ada dua, yaitu nama panggilan
        dikampung dan disekolah.
        Pada saat berada dikampung, saya dipanggilkan dengan nama "Palli", namun ketika berada disekolah saya dipanggil
        dengan nama "Padli".
        Pendidikan saya dimulai dengan bersekolah pada tingkat sekolah dasar dekat rumah saya yaitu SDN 23 Inpres
        Sirindu. Kemudian melanjutkan pendidikan
        ketingkat selanjutnya, yaitu Sekolah Menengah Pertama (SMP) di SMP Negeri 2 Pamboang dan melanjutkan lagi
        ketingkat yang lebih tinggi
        yaitu Sekolah Menengah Atas (SMA) di SMA Negeri 1 Pamboang.
    </p>
    <p>
        Saat lulus di tingkat SMA, saya masuk di Perguruan Tinggi Universitas Sulawesi Barat dengan mengambil jurusan
        Informatika melalui jalur Mandiri. Saya masuk di perguruan tinggi pada tahun 2021 dan saat itu masih berada pada
        masa pandemi Covid-19.
        Adanya pandemi ini menyebabkan semua aktivitas diluar rumah ditiadakan dan semua pekerja melakukakan
        pekerjaannya dirumah masing-masing demi menghindari adanya interaksi secara langsung antar orang untuk
        mencegah penularan covid-19 tersebut. Adanya pandemi ini juga memberikan dampak pada mahasiswa untuk melakukan
        aktivitas pembelajarannya. dirumah masing-masing melalui platform pembelajaran online seperti zoom, elearning dan lain-lain. Proses pembelajaran 
        yang dilakukan secara daring tersebut berlangsung selama dua semester yaitu semester 1-2. Saat ini 
        saya telah berada pada semester 6. 
    </p>
</fieldset>
