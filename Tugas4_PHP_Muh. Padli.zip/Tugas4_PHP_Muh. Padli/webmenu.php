<?php
$menu_atas =[
    'home' => 'Home',
    'produk' => 'Produk',
    'pesan' => 'Pesan',
    'galery' => 'Galery',
    'gesbuk' => 'Gesbuk'
];

$menu_bawah =[
    'home' => 'Home.php',
    'produk' => 'produk.php',
    'pesan' => 'pesan.php',
    'galery' => 'galery.php',
    'gesbuk'   => 'gesbuk.php'
];


?>