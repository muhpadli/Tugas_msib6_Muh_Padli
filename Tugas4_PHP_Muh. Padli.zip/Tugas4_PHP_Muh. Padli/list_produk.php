<?php
$list_produk = [
    'Kulkas'    => 2_000_000,
    'TV'        => 1_500_000,
    'Kipas Angin'   => 250_000,
    'Sound System'   => 500_000,
    'AC'            => 4_000_000,
    'Laptop'        => 6_500_000,
    'Smartphone'    => 2_500_000
];
?>
    
        
