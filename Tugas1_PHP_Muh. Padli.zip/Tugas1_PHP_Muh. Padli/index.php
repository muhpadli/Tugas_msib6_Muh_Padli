<frameset rows="20%,  *, 8%" cols="100%" frameborder="no">
    <frame src="header.php" scrolling="no" />
    <frameset>
        <frame src="home.php" scrolling="yes" name="main" >
    </frameset>
    <frameset>
        <frame src="footer.php">
    </frameset>
</frameset>
